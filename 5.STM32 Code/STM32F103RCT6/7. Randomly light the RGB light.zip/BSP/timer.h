#ifndef __TIMER_H
#define __TIMER_H

#include "AllHeader.h"

void TIM4_init(u16 arr , u16 psc);

#endif

